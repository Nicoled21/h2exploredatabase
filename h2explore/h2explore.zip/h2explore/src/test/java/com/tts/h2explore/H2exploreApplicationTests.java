package com.tts.h2explore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2exploreApplicationTests {

    @Test
    void contextLoads() {
    }

}
